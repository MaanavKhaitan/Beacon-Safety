//
//  LoginScreenViewController.swift
//  Beacon Alpha
//
//  Created by Maanav Khaitan on 2/13/16.
//  Copyright © 2016 Maanav Khaitan. All rights reserved.
//
import UIKit

class LoginScreenViewController: UIViewController, UITextFieldDelegate {
    
    @IBOutlet var yourName: UITextField!
    
    @IBOutlet var phoneNumber: UITextField!
    
    @IBOutlet var loginText: UILabel!
    var textFields: [UITextField]!
    
    
    
    @IBAction func lightItUp(sender: AnyObject) {
        
        NSUserDefaults.standardUserDefaults().setObject(true, forKey: "loginComplete")
        NSUserDefaults.standardUserDefaults().setObject(yourName.text, forKey: "Username")
        NSUserDefaults.standardUserDefaults().setObject(phoneNumber.text, forKey: "PhoneNumber")
        
        var loginIsComplete = NSUserDefaults.standardUserDefaults().objectForKey("loginComplete")
        
        
        
}
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        textFields = [yourName, phoneNumber]
        
        if NSUserDefaults.standardUserDefaults().objectForKey("loginComplete") == nil {
            
            loginText.text = "Enter your details below to get started:"
            
        }

        
        

        
        
        
        
        
        
     }
    
    override func viewDidAppear(animated: Bool) {
        
        
        
        
        
        
        
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    override func touchesBegan(touches: Set<UITouch>, withEvent event: UIEvent?) {
        
        
        self.view.endEditing(true)
        
    }
    
    func textFieldShouldReturn(textField: UITextField) -> Bool {
     
        yourName.resignFirstResponder()
        phoneNumber.resignFirstResponder()
        
        return true
        
    }

    
  
    
   

    
    
}

