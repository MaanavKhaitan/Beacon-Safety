//
//  ViewController.swift
//  Beacon Safety
//
//  Created by Maanav Khaitan on 2/13/16.
//  Copyright © 2016 Maanav Khaitan. All rights reserved.
//

import UIKit

class HomeViewController: UIViewController {
    
    let messageComposer = MessageComposer()

    @IBAction func alertNowButton(sender: AnyObject) {
        
        if (messageComposer.canSendText()) {
            // Obtain a configured MFMessageComposeViewController
            let messageComposeVC = messageComposer.configuredMessageComposeViewController()
            
            // Present the configured MFMessageComposeViewController instance
            // Note that the dismissal of the VC will be handled by the messageComposer instance,
            // since it implements the appropriate delegate call-back
            presentViewController(messageComposeVC, animated: true, completion: nil)
        } else {
            // Let the user know if his/her device isn't able to send text messages
            let alert : UIAlertController = UIAlertController(title: "Cannot Send Text Messages", message: "Your device is not able to send Text Messages", preferredStyle: UIAlertControllerStyle.Alert)
            alert.addAction(UIAlertAction(title: "Ok", style:.Default, handler: nil))
            self.presentViewController(alert, animated: true, completion: nil)
        }

    }
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

