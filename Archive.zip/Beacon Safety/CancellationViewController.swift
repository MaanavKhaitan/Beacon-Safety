//
//  CancellationViewController.swift
//  Beacon Safety
//
//  Created by Maanav Khaitan on 2/18/16.
//  Copyright © 2016 Maanav Khaitan. All rights reserved.
//

import UIKit

class CancellationViewController: UIViewController {
    
    @IBOutlet var uniqueCodeLabel: UILabel!
    @IBOutlet var uniqueCodeTextField: UITextField!
    
    var time = 0
    var timer = NSTimer()
   
    @IBOutlet var ignoreLabel: UILabel!
    
    func play() {
        
        time++
        
        if time > 5 {
            
            performSegueWithIdentifier("performAlert", sender: nil)
        }

        
    }

    @IBAction func cancelAlert(sender: AnyObject) {
        
        
        if uniqueCodeTextField.text == uniqueCodeLabel.text && time < 6{
            
            performSegueWithIdentifier("cancelIt", sender: self)
            
            }
        
        if uniqueCodeTextField.text != uniqueCodeLabel.text {
            
            ignoreLabel.text = "Code is incorrect."
        }

        
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        timer = NSTimer.scheduledTimerWithTimeInterval(1, target: self, selector: Selector("play"), userInfo: nil, repeats: true)
        
        var codeOne = Int(arc4random_uniform(10))
        var codeTwo = Int(arc4random_uniform(10))
        var codeThree = Int(arc4random_uniform(10))
        var codeFour = Int(arc4random_uniform(10))
        
        var uniqueCode = "\(codeOne)\(codeTwo)\(codeThree)\(codeFour)"
        
        uniqueCodeLabel.text = uniqueCode
        
        
        
        
        
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
}

