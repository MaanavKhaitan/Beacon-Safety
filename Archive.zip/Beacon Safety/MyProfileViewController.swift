//
//  MyProfileViewController.swift
//  Beacon Alpha
//
//  Created by Maanav Khaitan on 2/13/16.
//  Copyright © 2016 Maanav Khaitan. All rights reserved.
//

import UIKit

class MyProfileViewController: UIViewController {
    
    @IBOutlet var userNameMyProfile: UILabel!
    
    @IBOutlet var fullName: UITextField!
    
    @IBOutlet var phoneNumberMyProfile: UILabel!
    
    @IBOutlet var profileMobile: UITextField!
    
    @IBAction func saveProfile(sender: AnyObject) {
        
        NSUserDefaults.standardUserDefaults().setObject(fullName.text, forKey: "profileName")
        NSUserDefaults.standardUserDefaults().setObject(profileMobile.text, forKey: "mobileProfile")
        userNameMyProfile.text = NSUserDefaults.standardUserDefaults().objectForKey("profileName")! as! String
        phoneNumberMyProfile.text = NSUserDefaults.standardUserDefaults().objectForKey("mobileProfile")! as! String
        
        
        
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        if NSUserDefaults.standardUserDefaults().objectForKey("profileName") != nil && NSUserDefaults.standardUserDefaults().objectForKey("mobileProfile") != nil {
        
        userNameMyProfile.text = NSUserDefaults.standardUserDefaults().objectForKey("profileName")! as! String
        phoneNumberMyProfile.text = NSUserDefaults.standardUserDefaults().objectForKey("mobileProfile")! as! String
            
        }
        
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    override func touchesBegan(touches: Set<UITouch>, withEvent event: UIEvent?) {
        
        
        self.view.endEditing(true)
        
    }
    
    func textFieldShouldReturn(textField: UITextField) -> Bool {
        
        fullName.resignFirstResponder()
        profileMobile.resignFirstResponder()
        
        return true
        
    }

    
    
}


