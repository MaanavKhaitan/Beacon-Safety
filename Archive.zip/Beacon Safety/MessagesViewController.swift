//
//  MessagesViewController.swift
//  Beacon Alpha
//
//  Created by Maanav Khaitan on 2/11/16.
//  Copyright © 2016 Maanav Khaitan. All rights reserved.
//

import UIKit
import ContactsUI
import Contacts




class MessagesViewController: UIViewController, UITableViewDelegate, UITextFieldDelegate, UIPickerViewDelegate, CNContactPickerDelegate {
    
    
 
    
    
    @IBOutlet var contactsTableView: UITableView!
    
    var policeIsSelected = false
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        if policeIsSelected == false {
        
        contactFullNames.append("Police")
        contactPhoneNumbers.append("100")
            
        policeIsSelected = true
            
        }
        
        
        
        
        
        
        
        defaultMessage.text = ""
        
        
        if NSUserDefaults.standardUserDefaults().objectForKey("contactFullNames") != nil {
            
            contactFullNames = NSUserDefaults.standardUserDefaults().objectForKey("contactFullNames") as! [String]
        }
        
        if NSUserDefaults.standardUserDefaults().objectForKey("contactPhoneNumbers") != nil {
            
            contactPhoneNumbers = NSUserDefaults.standardUserDefaults().objectForKey("contactPhoneNumbers") as! [String]
        }
        
        
        
        
        
    }
    
    override func viewDidAppear(animated: Bool) {
        
        if policeIsSelected == false {
            
            contactFullNames.append("Police")
            contactPhoneNumbers.append("100")
            
            policeIsSelected = true
            
        }
        
        
        
        
        contactsTableView.reloadData()
        
        
        
        
    }


    
    func tableView(contactsTableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        return contactFullNames.count
    }
    
    func tableView(contactsTableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        
        let cell = UITableViewCell(style: UITableViewCellStyle.Default, reuseIdentifier: "Cell")
        
        cell.textLabel?.text = contactFullNames[indexPath.row]
        
        return cell
    }
    
    
    
    func tableView(contactsTableView: UITableView, commitEditingStyle editingStyle: UITableViewCellEditingStyle, forRowAtIndexPath indexPath: NSIndexPath) {
        
        if editingStyle == UITableViewCellEditingStyle.Delete {
            
            contactFullNames.removeAtIndex(indexPath.row)
            contactPhoneNumbers.removeAtIndex(indexPath.row)
            NSUserDefaults.standardUserDefaults().setObject(contactFullNames, forKey: "contactFullNames")
            NSUserDefaults.standardUserDefaults().setObject(contactPhoneNumbers, forKey: "contactPhoneNumbers")

            
            contactsTableView.reloadData()
        }
    }


    @IBOutlet var defaultMessage: UITextField!
    
    
    @IBOutlet var messageLabel: UILabel!
    
    override func touchesBegan(touches: Set<UITouch>, withEvent event: UIEvent?) {
        
        
        self.view.endEditing(true)
        
        
        NSUserDefaults.standardUserDefaults().setObject(defaultMessage.text, forKey: "DefaultMessage")
        
        messageLabel.text = "Last Saved: \(NSUserDefaults.standardUserDefaults().objectForKey("DefaultMessage") as! String)"
        
        
    }
    
    func textFieldShouldReturn(textField: UITextField) -> Bool {
        
        defaultMessage.resignFirstResponder()
        NSUserDefaults.standardUserDefaults().setObject(defaultMessage.text, forKey: "DefaultMessage")
        
        
        return true
        
    }
    
    
    

    
    @IBAction func addContacts(sender: AnyObject) {
    
        
        
        
}
    
  

        
       

    
    
    
    
  
    
    
        
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
        
     

    
    

    
    
    
}
