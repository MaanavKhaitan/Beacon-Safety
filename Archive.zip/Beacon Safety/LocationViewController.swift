//
//  LocationViewController.swift
//  Beacon Alpha
//
//  Created by Maanav Khaitan on 2/11/16.
//  Copyright © 2016 Maanav Khaitan. All rights reserved.
//

import UIKit
import MapKit
import CoreLocation


class LocationViewController: UIViewController, CLLocationManagerDelegate, MKMapViewDelegate {
    
    class func getLocationView() -> LocationViewController {
        return UIApplication.sharedApplication().delegate as! LocationViewController
    }

    

    @IBOutlet var map: MKMapView!
    
   
    @IBOutlet var yourLocation: UILabel!
    
    @IBOutlet var yourCoordinates: UILabel!
    var manager = CLLocationManager()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        
        manager.delegate = self
        manager.desiredAccuracy = kCLLocationAccuracyBest
        manager.requestAlwaysAuthorization()
        manager.requestWhenInUseAuthorization()
        manager.startUpdatingLocation()
        
        var latitude: CLLocationDegrees = 17.438738
        var longitude : CLLocationDegrees = 78.390790
        
        var latDelta: CLLocationDegrees = 0.01
        var lonDelta: CLLocationDegrees = 0.01
        
        var span: MKCoordinateSpan = MKCoordinateSpanMake(latDelta, lonDelta)
        
        var location: CLLocationCoordinate2D = CLLocationCoordinate2DMake(latitude, longitude)
        
        var region: MKCoordinateRegion = MKCoordinateRegionMake(location, span)
        
        map.setRegion(region, animated: true)
        
        
        
        
        
    }
    
        
    func locationManager(manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        
        
        print(locations)
        
        var userLocation: CLLocation = locations[locations.count - 1] as! CLLocation
        
        var longitude = userLocation.coordinate.longitude
        
        String(NSUserDefaults.standardUserDefaults().setObject(longitude, forKey: "userLongitude"))
        
        var latitude = userLocation.coordinate.latitude
        
        String(NSUserDefaults.standardUserDefaults().setObject(latitude, forKey: "userLatitude"))
        
        var course = userLocation.course
        
        var speed = userLocation.speed
        
        var altitude = userLocation.altitude
        
        var latDelta: CLLocationDegrees = 0.01
        var lonDelta: CLLocationDegrees = 0.01
        
        var span: MKCoordinateSpan = MKCoordinateSpanMake(latDelta, lonDelta)
        
        var location: CLLocationCoordinate2D = CLLocationCoordinate2DMake(latitude, longitude)
        
        var region: MKCoordinateRegion = MKCoordinateRegionMake(location, span)
        
        self.map.setRegion(region, animated: true)
        
        yourCoordinates.text = "\(latitude), \(longitude)"
        
        CLGeocoder().reverseGeocodeLocation(userLocation, completionHandler: {(placemarks, error) -> Void in
            print(location)
            
            if error != nil {
                print("Reverse geocoder failed with error" + error!.localizedDescription)
                return
            }
            
            if placemarks!.count > 0 {
                let pm = placemarks![0]
                print(pm.locality)
                
                self.yourLocation.text = "\(pm.locality!), \(pm.country!)"
                
                var myLocation: String = "\(latitude), \(longitude)"
                
            }
            else {
                print("Problem with the data received from geocoder")
            }
        })

        


        
      
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
   
   




    
    
    
    
}


