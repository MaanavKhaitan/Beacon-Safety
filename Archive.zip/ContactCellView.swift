//
//  ContactCellView.swift
//  Beacon Safety
//
//  Created by Maanav Khaitan on 2/27/16.
//  Copyright © 2016 Maanav Khaitan. All rights reserved.
//

import Foundation
